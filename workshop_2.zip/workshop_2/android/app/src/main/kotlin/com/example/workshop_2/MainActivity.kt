package com.example.workshop_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
